Showkeys is a Win2000/XP application.

The main purpose of this program is to show keys entered via 
a keyboard wedge interface as you find in barcode readers.

There are two output windows.

The upper one shows the keys entered as they probably would appear in
a regular application.
The lower one shows the keys entered with their system key names.

- The return key can be configured to begin a new line.

- Make/break can be shown only for modifier keys (shift ..) or for all keys.

- For manual tests you can filter the Auto-Repeat of the modifier keys (shift..).

- You can change the size of the main dialog. This size is automatically stored
  and re-used if you open the program the next time.

CAUTION:
You need a mouse or other pointing device because all keys are captured by this program.
The only way to leave it is to press the "Exit" button with the mouse.
You can however switch to other programs with the ALT+Tab method.
ALT+F4 does not leave the program. This is by design and not a bug.

CAUTION:
The very first release of this program had the two windows excanged in position.

Known bugs:
The Print Screen cannot be captured.

This program is a quick hack which I did in a few hours + a few more.

Ideas for improvements are very welcome.
Dieter Fauth

dieter.fauth@web.com

Installation:
Simply unzip it into a directory of you choice.
(Does not need any special .dll file to keep it simple.)
You can manually add links to the start menu or desktop if you like.

Enjoy!

