-------------------------------------------------------------------------------
Release Notes:
-------------------------------------------------------------------------------
None at this time.

-------------------------------------------------------------------------------
Purpose:
-------------------------------------------------------------------------------
I wrote this program to demonstrate what codepages are. Later I added the 
compare feature.

You can view, compare and print codepages.

-------------------------------------------------------------------------------
Freeware status:
-------------------------------------------------------------------------------
All versions 1.x.x.x are and will be freeware.
There might be a "pro" version as shareware in the future.

-------------------------------------------------------------------------------
Future Versions:
-------------------------------------------------------------------------------
Future versions will not run on Win9X anymore. You'll need Win2000 at least.
In this way I can remove the mixed ANSI/Unicode stuff and go to Unicode only.
This makes the code more readable. It also offers a few new API functions for 
the font and character handling.

-------------------------------------------------------------------------------
Hints:
-------------------------------------------------------------------------------
If you can't see characters for a exotic codepage (Arabic, Cyrilic, ...),
then your fonts are probably old (especially with Win95). 
Microsoft improved the fonts with each release of Windows.
The "Arial" for Win98SE contains about 1200 characters (Win95: 300).
The "Lucida Sans Unicode" of Windows NT/2000 contains about 1700 characters.
Newer fonts can be installed on older version of Windows, but I don't know if 
this would be legal.
I double checked the MS website and found that you can download new versions 
of "Arial" and some other fonts. These contain the WGL4 characters.
(Win98Se, WinME, Win2000 and WinXP users do not need to download the core 
fonts, but it's worth to look at the site anyway).
http://www.microsoft.com/typography/fontpack/default.htm
Now in 2003, March this page is no longer avaialable. 
For luck, today most people use Win2000 or XP.

And there is: Arial Unicode MS � 51,180 glyphs in version 0.86
This font file is around 23.0 MB, and using it can slow down your computer.
Family: � Sans-serif
Styles: � Regular
Availability: � Supplied with Microsoft Office 2000, FrontPage 2000, Office XP and Publisher 2002.


There is also the font "Cyberbit" from Adobe which used to be freeware, but 
now it has been removed from their website. I found it in the internet, but 
I don't know about the legal state. Contains a huge amount of charcters (Even Thai).
(the .zip file is > 6MByte!)

ftp://ftp.netscape.com/pub/communicator/extras/fonts/windows/
http://ftp36c.newaol.com/pub/communicator/extras/fonts/windows/Cyberbit.ZIP

And I found this one:
http://titus.uni-frankfurt.de/unicode/unitest2.htm#TITUUT
	This font includes, among others, a (nearly) full set of Korean, Japanese, and Chinese (Han) characters.
	Be careful: The font has a size of about 13 MB!
	N.B. The font does not include a full implementation of Latin diacritics, Ancient Greek, 
	Armenian, Georgian and the like, however.
	In cooperation with BITSTREAM, the TITUS project has prepared a Unicode Font (in Windows TTF format)
	to match the requirements of linguists and philologists working on
	several languages (ancient and modern). 
	This font (named "TITUS Cyberbit Basic") is available for non-commercial users only.

Another freeware font:
http://www.sil.org/~gaultney/gentium/

Another good site about fonts:	http://www.alanwood.net/unicode/fonts.html
-------------------------------------------------------------------------------
How to change the font:
-------------------------------------------------------------------------------
Use the menu "options/Select Font" and select the font in the dialog.

-------------------------------------------------------------------------------
Websites:
-------------------------------------------------------------------------------
www.microsoft.com/typography
www-cgrl.cs.mcgill.ca/~luc/freefonts.html
silverfish.org/fonteee/
www.alumni.caltech.edu/~dank/javafont.htm

www.unicode.org

-------------------------------------------------------------------------------
E-mail: fauthd@web.de
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
History:
-------------------------------------------------------------------------------
1.0.0.13:	Improved Font selection.
				Library update.
				Updated e-mail address.
1.0.0.14:	Recompiled with new lib.
1.0.0.15:	Added codepages for Nextstep and Adobe.
				The Selector dialogs can now be resized.
				Removed code for parsing .txt files from unicode.org from the release version.
1.0.0.16:	Added more information to the status line.
				A click into a character cell now copies some info to the Clipboard.
				This new clipboard function is experimental will change in the future.
				Format is: '['=0x5B,'�'	// U+00C3 : LATIN CAPITAL LETTER A WITH TILDE
1.0.0.17:	Added more codepages
				ISO 8859-11
				Mac Bulguarian
				Bulgarian Mic
				KOI-8E and F
				HP Roman8




