No installation required, just copy to a place of your choice.

For 64bit Windows you must use the x64 version. Otherwise not all
features are working correctly.

For Windows 7 there is a separate archive with Win7 in the name:
e.g.: ComPortCleaner_Win7_4_0_0_94
It might work on Win10 as well, but it is not tested.

For Windows 10 use the archive without Win7 in the name:
e.g.: ComPortCleaner_4_0_0_94

Windows XP is not supported anymore.

The about dialog will tell which flavor you are running.

Dieter Fauth 2019.07


