The example button setups in this directory can used for barcode scanners from Honeywell.
- example.yas	Is simply an example.
- prokey.yas	Can be handy if you need to send a prokey file to the device.
- eci.yas		Allow to control several settings regarding international support.

Importing can be done in seveal ways:
- Use menu/Strings/import...
- Open Strings setup and import there

eof
